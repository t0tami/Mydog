import static org.junit.jupiter.api.Assertions.*;

import org.example.SetDifferenceCalculator;
import org.example.SetMerger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.HashSet;
import java.util.Set;

public class Test4 {
    private SetDifferenceCalculator merger;

    @BeforeEach
    public void setUp() {
        merger = new SetDifferenceCalculator();
    }

    @Test
    public void testCalculateDifferenceWithNoOverlap() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(4, 5, 6));
        Set<Integer> differenceSet = merger.calculateDifference(set1, set2);
        System.out.println("Difference Set (No Overlap): " + differenceSet);
        assertEquals(Set.of(1, 2, 3), differenceSet);
    }

    @Test
    public void testCalculateDifferenceWithOverlap() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(2, 3, 4));
        Set<Integer> differenceSet = merger.calculateDifference(set1, set2);
        System.out.println("Difference Set (With Overlap): " + differenceSet);
        assertEquals(Set.of(1), differenceSet);
    }

    @Test
    public void testCalculateDifferenceWithEmptySet2() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>();
        Set<Integer> differenceSet = merger.calculateDifference(set1, set2);
        System.out.println("Difference Set (Empty Set 2): " + differenceSet);
        assertEquals(Set.of(1, 2, 3), differenceSet);
    }

    @Test
    public void testCalculateDifferenceWithEmptySet1() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> differenceSet = merger.calculateDifference(set1, set2);
        System.out.println("Difference Set (Empty Set 1): " + differenceSet);
        assertTrue(differenceSet.isEmpty());
    }

    @Test
    public void testCalculateDifferenceWithBothEmpty() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();
        Set<Integer> differenceSet = merger.calculateDifference(set1, set2);
        System.out.println("Difference Set (Both Empty): " + differenceSet);
        assertTrue(differenceSet.isEmpty());
    }
}