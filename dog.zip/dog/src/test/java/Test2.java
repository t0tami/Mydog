import org.example.SetIntersectionChecker;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.*;

public class Test2 {
    private final SetIntersectionChecker checker = new SetIntersectionChecker();

    @Test
    public void testIsIntersecting_WithCommonElements() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(3, 4, 5));
        assertTrue(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_WithoutCommonElements() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(4, 5, 6));
        assertFalse(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_EmptySets() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();
        assertFalse(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_OneEmptySet() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>();
        assertFalse(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_SameSet() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(1, 2, 3));
        assertTrue(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_LargeSets() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3, 1000, 2000));
        Set<Integer> set2 = new HashSet<>(Set.of(999, 1000, 2001));
        assertTrue(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_NonOverlappingLargeSets() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3, 9999));
        Set<Integer> set2 = new HashSet<>(Set.of(1000, 2001, 3001));
        assertFalse(checker.isIntersecting(set1, set2));
    }

    @Test
    public void testIsIntersecting_SingleElementOverlap() {
        Set<Integer> set1 = new HashSet<>(Set.of(10));
        Set<Integer> set2 = new HashSet<>(Set.of(10, 20, 30));
        assertTrue(checker.isIntersecting(set1, set2));
    }
}