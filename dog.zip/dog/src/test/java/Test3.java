import static org.junit.jupiter.api.Assertions.*;

import org.example.SetMerger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.HashSet;
import java.util.Set;

public class Test3 {
    private SetMerger merger;

    @BeforeEach
    public void setUp() {
        merger = new SetMerger();
    }

    @Test
    public void testMergeSetsWithNoOverlap() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(4, 5, 6));
        Set<Integer> mergedSet = merger.mergeSets(set1, set2);
        System.out.println("Merged Set (No Overlap): " + mergedSet);
        assertEquals(Set.of(1, 2, 3, 4, 5, 6), mergedSet);
    }

    @Test
    public void testMergeSetsWithOverlap() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>(Set.of(3, 4, 5));
        Set<Integer> mergedSet = merger.mergeSets(set1, set2);
        System.out.println("Merged Set (With Overlap): " + mergedSet);
        assertEquals(Set.of(1, 2, 3, 4, 5), mergedSet);
    }

    @Test
    public void testMergeSetsWithEmptySet1() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> mergedSet = merger.mergeSets(set1, set2);
        System.out.println("Merged Set (Empty Set 1): " + mergedSet);
        assertEquals(Set.of(1, 2, 3), mergedSet);
    }

    @Test
    public void testMergeSetsWithEmptySet2() {
        Set<Integer> set1 = new HashSet<>(Set.of(1, 2, 3));
        Set<Integer> set2 = new HashSet<>();
        Set<Integer> mergedSet = merger.mergeSets(set1, set2);
        System.out.println("Merged Set (Empty Set 2): " + mergedSet);
        assertEquals(Set.of(1, 2, 3), mergedSet);
    }

    @Test
    public void testMergeSetsWithBothEmpty() {
        Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();
        Set<Integer> mergedSet = merger.mergeSets(set1, set2);
        System.out.println("Merged Set (Both Empty): " + mergedSet);
        assertTrue(mergedSet.isEmpty());
    }
}