import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class test {
   @Test
    public void testExtractorUniqueNumbersWithDuplicates(){
       UniqueNumberExtractor extractor = new UniqueNumberExtractor();
       List<Integer> numbers = Arrays.asList(1,2,3,4,5);

       Set<Integer> expectedUniqueNumbers = new HashSet<>(Arrays.asList(1,2,3,4,5));
       Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

       assertEquals(expectedUniqueNumbers, actualUniqueNumbers);
    }
    @Test
    public void testExtractUniqueNumbersEmptyList(){
       UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList();

        Set<Integer> expectedUniqueNumbers = new HashSet<>();
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectedUniqueNumbers, actualUniqueNumbers);


    }
    @Test
    public void testExtractorUniqueNumbersNoDuplicates(){
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(1,2,3,4,5);

        Set<Integer> expectedUniqueNumbers = new HashSet<>(Arrays.asList(1,2,3,4,5));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectedUniqueNumbers, actualUniqueNumbers);
    }
    @Test
    public void testExtractorUniqueNumbersWithNegativeNumbers(){
        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(-1,-2,-3,-4,-5);

        Set<Integer> expectedUniqueNumbers = new HashSet<>(Arrays.asList(-1,-2,-3,-4,-5));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectedUniqueNumbers, actualUniqueNumbers);
    }
    @Test
            public void testExtractorUniqueNumbersAllDuplicates() {

        UniqueNumberExtractor extractor = new UniqueNumberExtractor();
        List<Integer> numbers = Arrays.asList(2, 2, 2, 2);

        Set<Integer> expectedUniqueNumbers = new HashSet<>(Arrays.asList(2));
        Set<Integer> actualUniqueNumbers = extractor.extractUniqueNumbers(numbers);

        assertEquals(expectedUniqueNumbers, actualUniqueNumbers);
    }
}
